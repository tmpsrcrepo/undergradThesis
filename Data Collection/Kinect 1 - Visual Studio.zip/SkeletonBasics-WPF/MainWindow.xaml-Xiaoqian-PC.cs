﻿//------------------------------------------------------------------------------
// <copyright file="MainWindow.xaml.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------

namespace Microsoft.Samples.Kinect.SkeletonBasics
{
    using System.IO;
    using System.Windows;
    using System.Windows.Media;
    using Microsoft.Kinect;
    using System.Windows.Navigation;
    using System;
    using System.Globalization;
   // using "NuiApi.h"

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// Width of output drawing
        /// </summary>
        private const float RenderWidth = 640.0f;

        /// <summary>
        /// Height of our output drawing
        /// </summary>
        private const float RenderHeight = 480.0f;

        /// <summary>
        /// Thickness of drawn joint lines
        /// </summary>
        private const double JointThickness = 3;

        /// <summary>
        /// Thickness of body center ellipse
        /// </summary>
        private const double BodyCenterThickness = 10;

        /// <summary>
        /// Thickness of clip edge rectangles
        /// </summary>
        private const double ClipBoundsThickness = 10;

        /// <summary>
        /// Brush used to draw skeleton center point
        /// </summary>
        private readonly Brush centerPointBrush = Brushes.Blue;
        //
        /// <summary>
        /// Brush used for drawing joints that are currently tracked
        /// </summary>
        private readonly Brush trackedJointBrush = new SolidColorBrush(Color.FromArgb(255, 68, 192, 68));

        /// <summary>
        /// Brush used for drawing joints that are currently inferred
        /// </summary>        
        private readonly Brush inferredJointBrush = Brushes.Yellow;
    

        /// <summary>
        /// Pen used for drawing bones that are currently tracked
        /// </summary>
        private readonly Pen trackedBonePen = new Pen(Brushes.Green, 6);

        /// <summary>
        /// Pen used for drawing bones that are currently inferred
        /// </summary>        
        private readonly Pen inferredBonePen = new Pen(Brushes.Gray, 1);

        /// <summary>
        /// Active Kinect sensor
        /// </summary>
        private KinectSensor sensor;
     //   private KinectSensor sensor_2;

        /// <summary>
        /// Drawing group for skeleton rendering output
        /// </summary>
        private DrawingGroup drawingGroup;

        /// <summary>
        /// Drawing image that we will display
        /// </summary>
        private DrawingImage imageSource;

        /// <summary>
        /// Initializes a new instance of the MainWindow class.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Draws indicators to show which edges are clipping skeleton data
        /// </summary>
        /// <param name="skeleton">skeleton to draw clipping information for</param>
        /// <param name="drawingContext">drawing context to draw to</param>
        private static void RenderClippedEdges(Skeleton skeleton, DrawingContext drawingContext)
        {
            if (skeleton.ClippedEdges.HasFlag(FrameEdges.Bottom))
            {
                drawingContext.DrawRectangle(
                    Brushes.Red,
                    null,
                    new Rect(0, RenderHeight - ClipBoundsThickness, RenderWidth, ClipBoundsThickness));
            }

            if (skeleton.ClippedEdges.HasFlag(FrameEdges.Top))
            {
                drawingContext.DrawRectangle(
                    Brushes.Red,
                    null,
                    new Rect(0, 0, RenderWidth, ClipBoundsThickness));
            }

            if (skeleton.ClippedEdges.HasFlag(FrameEdges.Left))
            {
                drawingContext.DrawRectangle(
                    Brushes.Red,
                    null,
                    new Rect(0, 0, ClipBoundsThickness, RenderHeight));
            }

            if (skeleton.ClippedEdges.HasFlag(FrameEdges.Right))
            {
                drawingContext.DrawRectangle(
                    Brushes.Red,
                    null,
                    new Rect(RenderWidth - ClipBoundsThickness, 0, ClipBoundsThickness, RenderHeight));
            }
        }

        /// <summary>
        /// Execute startup tasks
        /// </summary>
        /// <param name="sender">object sending the event</param>
        /// <param name="e">event arguments</param>
        private void WindowLoaded(object sender, RoutedEventArgs e)
        {
            // Create the drawing group we'll use for drawing
            this.drawingGroup = new DrawingGroup();

            // Create an image source that we can use in our image control
            this.imageSource = new DrawingImage(this.drawingGroup);

            // Display the drawing using our image control
            Image.Source = this.imageSource;

            // Look through all sensors and start the first connected one.
            // This requires that a Kinect is connected at the time of app startup.
            // To make your app robust against plug/unplug, 
            // it is recommended to use KinectSensorChooser provided in Microsoft.Kinect.Toolkit
           
            /* foreach (var potentialSensor in KinectSensor.KinectSensors)
            {
                if (potentialSensor.Status == KinectStatus.Connected)
                {
                    this.sensor = potentialSensor;
                    break;
                }
            }*/

            this.sensor = KinectSensor.KinectSensors[0];
       //     this.sensor_2 = KinectSensor.KinectSensors[1];

            if (null != this.sensor)
            {
                // Turn on the skeleton stream to receive skeleton frames
                this.sensor.SkeletonStream.Enable();
         //       this.sensor_2.SkeletonStream.Enable();

                // Add an event handler to be called whenever there is new color frame data
                this.sensor.SkeletonFrameReady += this.SensorSkeletonFrameReady;
        //        this.sensor_2.SkeletonFrameReady += this.SensorSkeletonFrameReady;
                // Start the sensor!
                try
                {
                    this.sensor.Start();
                }
                catch (IOException)
                {
                    this.sensor = null;
                }
            }

            if (null == this.sensor)
            {
                this.statusBarText.Text = Properties.Resources.NoKinectReady;
            }
        }

        /// <summary>
        /// Execute shutdown tasks
        /// </summary>
        /// <param name="sender">object sending the event</param>
        /// <param name="e">event arguments</param>
        private void WindowClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (null != this.sensor)
            {
                this.sensor.Stop();
            }
        }

        /// <summary>
        /// Event handler for Kinect sensor's SkeletonFrameReady event
        /// </summary>
        /// <param name="sender">object sending the event</param>
        /// <param name="e">event arguments</param>
        private void SensorSkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            Skeleton[] skeletons = new Skeleton[0];
            if (!File.Exists("collection.csv"))
            {
                File.AppendAllText("collection.csv", "Seconds,Time,h_x,h_y,h_z,h_state,sc_x,sc_y,sc_z,sc_state,sr_x,sr_y,sr_z,sr_state,sl_x,sl_y,sl_z,sl_state,el_x,el_y,el_z,el_state,er_x,er_y,er_z,er_state,hl_x,hl_y,hl_z,hl_state,hr_x,hr_y,hr_z,hr_state,wl_x,wl_y,wl_z,wl_state,wr_x,wr_y,wr_z,wr_state");
        //        "time,HD_s,HD_x,HD_y,HD_z,SC_s,SC_x,SC_y,SC_z,SL_s,SL_x,SL_y,SL_z,EL_s,EL_x,EL_y,EL_z,WL_s,WL_x,WL_y,WL_z,HL_s,HL_x,HL_y,HL_z,SR_s,SR_x,SR_y,SR_z,ER_s,ER_x,ER_y,ER_z,WR_s,WR_x,WR_y,WR_z,HR_s,HR_x,HR_Y,HR_z"

            }

            using (SkeletonFrame skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame != null)
                {
                    skeletons = new Skeleton[skeletonFrame.SkeletonArrayLength];
                    skeletonFrame.CopySkeletonDataTo(skeletons);
                }
            }

            using (DrawingContext dc = this.drawingGroup.Open())
            {
                // Draw a transparent background to set the render size
                dc.DrawRectangle(Brushes.Black, null, new Rect(0.0, 0.0, RenderWidth, RenderHeight));
               
                if (skeletons.Length != 0)
                {
               

                    foreach (Skeleton skel in skeletons)
                    {
                        RenderClippedEdges(skel, dc);

                        if (skel.TrackingState == SkeletonTrackingState.Tracked)
                        {
                            this.DrawBonesAndJoints(skel, dc);
                        }
                        else if (skel.TrackingState == SkeletonTrackingState.PositionOnly)
                        {
                            dc.DrawEllipse(
                            this.centerPointBrush,
                            null,
                            this.SkeletonPointToScreen(skel.Position),
                            BodyCenterThickness,
                            BodyCenterThickness);
                        }
                        //5-21
                       
                      export(skel, "collection.csv");
                  

                    

                    }
                }

                // prevent drawing outside of our render area
                this.drawingGroup.ClipGeometry = new RectangleGeometry(new Rect(0.0, 0.0, RenderWidth, RenderHeight));
            }

            
        }
        //convert skeletonpoint to screenpoint
        private System.Windows.Point MapSkeletonToScreen(KinectSensor sensor, SkeletonPoint skeletonPoint)
        {
            const double scale = 1080.0 / 480.0;
            const double xOffset = 1920.0 - (640.0 * scale) / 2;
            
            DepthImagePoint depthImagePoint = sensor.CoordinateMapper.MapSkeletonPointToDepthPoint(
                skeletonPoint, 
                DepthImageFormat.Resolution640x480Fps30);
         
            return new System.Windows.Point(xOffset + (scale * depthImagePoint.X), (scale * depthImagePoint.Y));
        }

        /// <summary>
        /// Draws a skeleton's bones and joints
        /// </summary>
        /// <param name="skeleton">skeleton to draw</param>
        /// <param name="drawingContext">drawing context to draw to</param>

        /***********************************: print coordinates of skeletonpoints on the screen*********************************************************/
        private void DrawCoordinates(Skeleton skeleton, DrawingContext drawingContext, JointType h)
        {
            Point coord = SkeletonPointToScreen(skeleton.Joints[h].Position);
            Joint head = skeleton.Joints[h];
            //   Joint Write
            double hx = Math.Round(head.Position.X,3);
            double hy = Math.Round(head.Position.Y, 3);
            double hz = Math.Round(head.Position.Z, 3);
            string testString = "( " + hx.ToString() + " " + hy.ToString() + " " + hz.ToString() + ")";
            FormattedText formattedText = new FormattedText(testString, CultureInfo.GetCultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 12, Brushes.Green);
            drawingContext.DrawText(formattedText, coord);

        }
        //5/20
        private void DrawBonesAndJoints(Skeleton skeleton, DrawingContext drawingContext)
        {
            
            
            // Render Torso
            this.DrawBone(skeleton, drawingContext, JointType.Head, JointType.ShoulderCenter);
            
            this.DrawBone(skeleton, drawingContext, JointType.ShoulderCenter, JointType.ShoulderLeft);

        /***********************************: print coordinates of skeletonpoints on the screen*********************************************************/

            //head
            DrawCoordinates(skeleton, drawingContext, JointType.Head);
            //shoulderCenter
            DrawCoordinates(skeleton, drawingContext, JointType.ShoulderCenter);
           //shoulderRight
            DrawCoordinates(skeleton, drawingContext, JointType.ShoulderRight);
            //shoulderLeft
            DrawCoordinates(skeleton, drawingContext, JointType.ShoulderLeft);
            //elbowleft
            DrawCoordinates(skeleton, drawingContext, JointType.ElbowLeft);
            //elbowright
            DrawCoordinates(skeleton, drawingContext, JointType.ElbowRight);
            //WristLeft
            DrawCoordinates(skeleton, drawingContext, JointType.WristLeft);
            //WristRight
            DrawCoordinates(skeleton, drawingContext, JointType.WristRight);
            //HandLeft
            DrawCoordinates(skeleton, drawingContext, JointType.HandLeft);
            //HandRight
            DrawCoordinates(skeleton, drawingContext, JointType.HandRight);





            this.DrawBone(skeleton, drawingContext, JointType.ShoulderCenter, JointType.ShoulderRight);
            this.DrawBone(skeleton, drawingContext, JointType.ShoulderCenter, JointType.Spine);
            this.DrawBone(skeleton, drawingContext, JointType.Spine, JointType.HipCenter);
            this.DrawBone(skeleton, drawingContext, JointType.HipCenter, JointType.HipLeft);
            this.DrawBone(skeleton, drawingContext, JointType.HipCenter, JointType.HipRight);
            
            // Left Arm
            this.DrawBone(skeleton, drawingContext, JointType.ShoulderLeft, JointType.ElbowLeft);
            this.DrawBone(skeleton, drawingContext, JointType.ElbowLeft, JointType.WristLeft);
            this.DrawBone(skeleton, drawingContext, JointType.WristLeft, JointType.HandLeft);
            

            // Right Arm
            this.DrawBone(skeleton, drawingContext, JointType.ShoulderRight, JointType.ElbowRight);
            this.DrawBone(skeleton, drawingContext, JointType.ElbowRight, JointType.WristRight);
            this.DrawBone(skeleton, drawingContext, JointType.WristRight, JointType.HandRight);

            // Left Leg
            this.DrawBone(skeleton, drawingContext, JointType.HipLeft, JointType.KneeLeft);
            this.DrawBone(skeleton, drawingContext, JointType.KneeLeft, JointType.AnkleLeft);
            this.DrawBone(skeleton, drawingContext, JointType.AnkleLeft, JointType.FootLeft);

            // Right Leg
            this.DrawBone(skeleton, drawingContext, JointType.HipRight, JointType.KneeRight);
            this.DrawBone(skeleton, drawingContext, JointType.KneeRight, JointType.AnkleRight);
            this.DrawBone(skeleton, drawingContext, JointType.AnkleRight, JointType.FootRight);
            // Render Joints
            foreach (Joint joint in skeleton.Joints)
            {
               
                Brush drawBrush = null;

                if (joint.TrackingState == JointTrackingState.Tracked)
                {
                    drawBrush = this.trackedJointBrush;                    
                }
                else if (joint.TrackingState == JointTrackingState.Inferred)
                {
                    drawBrush = this.inferredJointBrush;                    
                }

                if (drawBrush != null)
                {
                    drawingContext.DrawEllipse(drawBrush, null, this.SkeletonPointToScreen(joint.Position), JointThickness, JointThickness);

                }

                 
            }

         

        }
        //5/20
        /*****************************Export*********************************************************************/
        private void export(Skeleton skeleton, String filename)
        {
            Joint head = skeleton.Joints[JointType.Head];

            double hx = head.Position.X;
            double hy = head.Position.Y;
            double hz = head.Position.Z;

            Joint sc = skeleton.Joints[JointType.ShoulderCenter];
            Joint sr = skeleton.Joints[JointType.ShoulderLeft];
            Joint sl = skeleton.Joints[JointType.ShoulderRight];
            Joint el = skeleton.Joints[JointType.ElbowLeft];
            Joint er = skeleton.Joints[JointType.ElbowRight];
            Joint hl = skeleton.Joints[JointType.HandLeft];
            Joint hr = skeleton.Joints[JointType.HandRight];
            Joint sp = skeleton.Joints[JointType.Spine];
            Joint wl = skeleton.Joints[JointType.WristLeft];
            Joint wr = skeleton.Joints[JointType.WristRight];

            double scx = sc.Position.X;
            double scy = sc.Position.Y;
            double scz = sc.Position.Z;

            double srx = sr.Position.X;
            double sry = sr.Position.Y;
            double srz = sr.Position.Z;

            double slx = sl.Position.X;
            double sly = sl.Position.Y;
            double slz = sl.Position.Z;

            double elx = el.Position.X;
            double ely = el.Position.Y;
            double elz = el.Position.Z;

            double erx = er.Position.X;
            double ery = er.Position.Y;
            double erz = er.Position.Z;

            double hlx = hl.Position.X;
            double hly = hl.Position.Y;
            double hlz = hl.Position.Z;

            double hrx = hr.Position.X;
            double hry = hr.Position.Y;
            double hrz = hr.Position.Z;

            double spx = sp.Position.X;
            double spy = sp.Position.Y;
            double spz = sp.Position.Z;

            double wlx = wl.Position.X;
            double wly = wl.Position.Y;
            double wlz = wl.Position.Z;

            double wrx = wr.Position.X;
            double wry = wr.Position.Y;
            double wrz = wr.Position.Z;


                
                  if (head.TrackingState == JointTrackingState.Inferred | head.TrackingState==JointTrackingState.Tracked)
                {
                //    File.AppendAllText(filename, "\n");
                    File.AppendAllText("collection.csv", "\n");
                    
                    DateTime now = DateTime.Now;
                    var currenttime = now.ToString("mm:ss");
                    //double seconds = TimeSpan.Parse(currenttime).TotalSeconds;
                    //File.AppendAllText("Collection.csv", seconds+",");
                    File.AppendAllText("collection.csv", currenttime+",");
                    File.AppendAllText(filename, string.Join(",", new[] { Math.Round(hx,3), Math.Round(hy,3), Math.Round(hz,3) }));
                    File.AppendAllText(filename, "," + head.TrackingState + ",");
                  }
                 
                if(sc.TrackingState==JointTrackingState.Tracked|sc.TrackingState==JointTrackingState.Inferred){
                    File.AppendAllText(filename, string.Join(",", new[] { Math.Round(scx,3), Math.Round(scy,3), Math.Round(scz,3) }));
                    File.AppendAllText(filename, "," + sc.TrackingState+",");
                }
                 if(sr.TrackingState==JointTrackingState.Tracked|sr.TrackingState==JointTrackingState.Inferred){
                    File.AppendAllText(filename, string.Join(",", new[] { Math.Round(srx,3), Math.Round(sry,3), Math.Round(srz,3) }));
                    File.AppendAllText(filename, "," + sr.TrackingState + ",");
                 }
                 if(sc.TrackingState==JointTrackingState.Tracked|sc.TrackingState==JointTrackingState.Inferred){
                    File.AppendAllText(filename, string.Join(",", new[] { Math.Round(slx,3), Math.Round(sly,3), Math.Round(slz,3) }));
                    File.AppendAllText(filename, "," + sl.TrackingState + ",");
                }
                if(el.TrackingState!=JointTrackingState.NotTracked){
                    File.AppendAllText(filename, string.Join(",", new[] { Math.Round(elx,3), Math.Round(ely,3), Math.Round(elz,3) }));
                    File.AppendAllText(filename, "," + el.TrackingState + ",");
                }
                 if(er.TrackingState!=JointTrackingState.NotTracked){
                    File.AppendAllText(filename, string.Join(",", new[] { Math.Round(erx,3), Math.Round(ery,3), Math.Round(erz,3) }));
                    File.AppendAllText(filename, "," + er.TrackingState + ",");
                 }
            
            if(hl.TrackingState!=JointTrackingState.NotTracked){
                    File.AppendAllText(filename, string.Join(",", new[] { Math.Round(hlx,3), Math.Round(hly,3), Math.Round(hlz,3) }));
                    File.AppendAllText(filename, "," + hl.TrackingState + ",");
            } 
            if(hr.TrackingState!=JointTrackingState.NotTracked){
                    File.AppendAllText(filename, string.Join(",", new[] { Math.Round(hrx,3), Math.Round(hry,3), Math.Round(hrz,3) }));
                    File.AppendAllText(filename, "," + hr.TrackingState + ",");
            }
          
            if (wl.TrackingState != JointTrackingState.NotTracked)
            {
                File.AppendAllText(filename, string.Join(",", new[] { Math.Round(wlx,3), Math.Round(wly,3), Math.Round(wlz,3) }));
                File.AppendAllText(filename, "," + wl.TrackingState + ",");
            }
           
                if (wr.TrackingState == JointTrackingState.Inferred |wr.TrackingState==JointTrackingState.Tracked)
                {
                    File.AppendAllText(filename, string.Join(",", new[] { Math.Round(wrx,3), Math.Round(wry,3), Math.Round(wrz,3) }));
                    File.AppendAllText(filename, "," + wr.TrackingState);
                }

                


        }


        /// <summary>
        /// Maps a SkeletonPoint to lie within our render space and converts to Point
        /// </summary>
        /// <param name="skelpoint">point to map</param>
        /// <returns>mapped point</returns>
        private Point SkeletonPointToScreen(SkeletonPoint skelpoint)
        {
            // Convert point to depth space.  
            // We are not using depth directly, but we do want the points in our 640x480 output resolution.
            DepthImagePoint depthPoint = this.sensor.CoordinateMapper.MapSkeletonPointToDepthPoint(skelpoint, DepthImageFormat.Resolution640x480Fps30);
            return new Point(depthPoint.X, depthPoint.Y);
        }

        /// <summary>
        /// Draws a bone line between two joints
        /// </summary>
        /// <param name="skeleton">skeleton to draw bones from</param>
        /// <param name="drawingContext">drawing context to draw to</param>
        /// <param name="jointType0">joint to start drawing from</param>
        /// <param name="jointType1">joint to end drawing at</param>
        private void DrawBone(Skeleton skeleton, DrawingContext drawingContext, JointType jointType0, JointType jointType1)
        {
            Joint joint0 = skeleton.Joints[jointType0];
            Joint joint1 = skeleton.Joints[jointType1];

            // If we can't find either of these joints, exit
            if (joint0.TrackingState == JointTrackingState.NotTracked ||
                joint1.TrackingState == JointTrackingState.NotTracked)
            {
                return;
            }

            // Don't draw if both points are inferred
            if (joint0.TrackingState == JointTrackingState.Inferred &&
                joint1.TrackingState == JointTrackingState.Inferred)
            {
                return;
            }

            // We assume all drawn bones are inferred unless BOTH joints are tracked
            Pen drawPen = this.inferredBonePen;
            if (joint0.TrackingState == JointTrackingState.Tracked && joint1.TrackingState == JointTrackingState.Tracked)
            {
                drawPen = this.trackedBonePen;
            }

            drawingContext.DrawLine(drawPen, this.SkeletonPointToScreen(joint0.Position), this.SkeletonPointToScreen(joint1.Position));
        }

        /// <summary>
        /// Handles the checking or unchecking of the seated mode combo box
        /// </summary>
        /// <param name="sender">object sending the event</param>
        /// <param name="e">event arguments</param>
        private void CheckBoxSeatedModeChanged(object sender, RoutedEventArgs e)
        {
            if (null != this.sensor)
            {
                if (this.checkBoxSeatedMode.IsChecked.GetValueOrDefault())
                {
                    this.sensor.SkeletonStream.TrackingMode = SkeletonTrackingMode.Seated;
                }
                else
                {
                    this.sensor.SkeletonStream.TrackingMode = SkeletonTrackingMode.Default;
                }
            }
        }

       
    }
}